import AWS from 'aws-sdk';
const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE = process.env.TABLE_NAME || process.env.USERS_TABLE || 'fitness_planner';

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const id = event?.pathParameters?.userId || body.id;
    if (!id) return { statusCode: 400, headers: cors(), body: 'id required' };
    const expr = [];
    const names = {};
    const values = {};
    const set = (k, v) => { const nk = `#${k}`; const vk = `:${k}`; names[nk] = k; values[vk] = v; expr.push(`${nk} = ${vk}`); };
    ['email','givenName','familyName','role','companyId','trainerId'].forEach(k => {
      if (body[k] !== undefined) set(k, body[k]);
    });
    const resp = await ddb.update({
      TableName: TABLE,
      Key: { PK: `USER#${id}`, SK: `USER#${id}` },
      UpdateExpression: `SET ${expr.join(', ')}`,
      ExpressionAttributeNames: names,
      ExpressionAttributeValues: values,
      ReturnValues: 'ALL_NEW'
    }).promise();
    return ok(resp.Attributes || {});
  } catch (e) { return err(e); }
};

const ok = (data) => ({ statusCode: 200, headers: cors(), body: JSON.stringify(data) });
const err = (e) => ({ statusCode: 500, headers: cors(), body: JSON.stringify({ error: e.message || 'error' }) });
const cors = () => ({ 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
