import AWS from 'aws-sdk';
const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE = process.env.TABLE_NAME || process.env.USERS_TABLE || 'fitness_planner';

export const handler = async (event) => {
  try {
    const qs = event.queryStringParameters || {};
    const trainerId = qs.trainerId;
    const companyId = qs.companyId;

    // Simple GSIs expected: GSI1 for trainerId, GSI2 for companyId
    if (trainerId) {
      const resp = await ddb.query({
        TableName: TABLE,
        IndexName: 'GSI1',
        KeyConditionExpression: 'trainerId = :t',
        ExpressionAttributeValues: { ':t': trainerId }
      }).promise();
      return ok(resp.Items || []);
    }
    if (companyId) {
      const resp = await ddb.query({
        TableName: TABLE,
        IndexName: 'GSI2',
        KeyConditionExpression: 'companyId = :c',
        ExpressionAttributeValues: { ':c': companyId }
      }).promise();
      return ok(resp.Items || []);
    }
    return ok([]);
  } catch (e) { return err(e); }
};

const ok = (data) => ({ statusCode: 200, headers: cors(), body: JSON.stringify(data) });
const err = (e) => ({ statusCode: 500, headers: cors(), body: JSON.stringify({ error: e.message || 'error' }) });
const cors = () => ({ 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
