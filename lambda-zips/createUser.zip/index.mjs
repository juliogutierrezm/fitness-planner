// Use AWS SDK v2 available in Lambda runtime
import AWS from 'aws-sdk';
const ddb = new AWS.DynamoDB.DocumentClient();
const TABLE = process.env.TABLE_NAME || process.env.USERS_TABLE || 'fitness_planner';

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body || '{}');
    const now = new Date().toISOString();
    const id = body.id || `usr-${Date.now()}`;
    const item = {
      PK: `USER#${id}`,
      SK: `USER#${id}`,
      id,
      email: body.email,
      givenName: body.givenName || '',
      familyName: body.familyName || '',
      role: body.role || 'client',
      companyId: body.companyId,
      trainerId: body.trainerId,
      createdAt: now
    };
    await ddb.put({ TableName: TABLE, Item: item }).promise();
    return ok(item);
  } catch (e) { return err(e); }
};

const ok = (data) => ({ statusCode: 200, headers: cors(), body: JSON.stringify(data) });
const err = (e) => ({ statusCode: 500, headers: cors(), body: JSON.stringify({ error: e.message || 'error' }) });
const cors = () => ({ 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type,Authorization' });
