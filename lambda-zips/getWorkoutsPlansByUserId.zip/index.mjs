import AWS from 'aws-sdk';
const ddb = new AWS.DynamoDB.DocumentClient();

// Defaults to existing naming seen in repo
const TABLE = process.env.WORKOUT_PLANS_TABLE || 'WorkoutPlans';
const USER_INDEX = process.env.WORKOUT_PLANS_USERID_INDEX || null; // e.g., 'userId-index'

const cors = () => ({
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization'
});

export const handler = async (event) => {
  try {
    const userId = event?.pathParameters?.userId || event?.queryStringParameters?.userId;
    if (!userId) return { statusCode: 400, headers: cors(), body: JSON.stringify({ message: 'userId requerido' }) };

    let items = [];
    if (USER_INDEX) {
      // Prefer a GSI if available
      const resp = await ddb.query({
        TableName: TABLE,
        IndexName: USER_INDEX,
        KeyConditionExpression: 'userId = :u',
        ExpressionAttributeValues: { ':u': userId }
      }).promise();
      items = resp.Items || [];
    } else {
      // Fallback: Scan + FilterExpression
      const resp = await ddb.scan({
        TableName: TABLE,
        FilterExpression: 'userId = :u',
        ExpressionAttributeValues: { ':u': userId }
      }).promise();
      items = resp.Items || [];
    }
    // Sort by date descending if date exists
    items.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return { statusCode: 200, headers: cors(), body: JSON.stringify(items) };
  } catch (e) {
    console.error(e);
    return { statusCode: 500, headers: cors(), body: JSON.stringify({ message: 'Error obteniendo planes del usuario' }) };
  }
};

